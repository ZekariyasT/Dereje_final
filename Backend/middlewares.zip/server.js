// // mun8WtTAlO1w7mMv

import express from "express";
import dotenv from "dotenv";
import { connectDB } from "./config/db.js";
import productRoutes from "./routes/product.route.js";
import blogRoutes from "./routes/blog.route.js";
import adminAuthRoutes from "./routes/adminAuth.route.js";
import BeforeAfterImageRoutes from "./routes/beforeAfterImage.route.js";
import userRouter from "./routes/user.js";
import orderRouter from "./routes/order.js";
import cors from "cors";
import path from "path";
import { fileURLToPath } from "url";
import { dirname } from "path";
import mongoose from "mongoose";

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const app = express();

// CORS configuration
app.use(cors({
  origin: 'https://derejeturaengineering.com',
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization'],
  credentials: true,
  preflightContinue: false,
  optionsSuccessStatus: 204
}));

// Handle preflight requests
app.options('*', cors({
  origin: 'https://derejeturaengineering.com',
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization'],
  credentials: true
}));

app.use(express.json({ limit: "50mb" }));
app.use(express.urlencoded({ limit: "50mb", extended: true }));

// Serve uploaded files statically from /uploads
app.use("/uploads", express.static(path.join(__dirname, "uploads")));

// API routes without /api prefix since we're on api subdomain
app.use("/blogs", blogRoutes);
app.use("/products", productRoutes);
app.use("/admin", adminAuthRoutes);
app.use("/beforeAfterImages", BeforeAfterImageRoutes);
app.use('/users', userRouter);
app.use('/orders', orderRouter);

// MongoDB Connection
mongoose.connect(process.env.MONGODB_URI, {
    useNewUrlParser: true,
    useUnifiedTopology: true
})
.then(() => console.log('MongoDB connection established'))
.catch(err => console.log('MongoDB connection error:', err));

// Error handling middleware
app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).json({ error: 'Something broke!' });
});

// Not found middleware
app.use((req, res) => {
    res.status(404).json({ error: 'Not Found' });
});

// Health check endpoint
app.get('/health', (req, res) => {
    res.status(200).json({ status: 'OK', message: 'Server is running' });
});

const PORT = process.env.PORT || 5000;

app.listen(PORT, async () => {
  await connectDB();
  console.log(`Server started at http://localhost:${PORT}`);
});
